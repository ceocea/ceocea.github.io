﻿
<html xmlns="http://www.w3.org/1999/xhtml">
	
<script language=JavaScript> 
	<!-- 
	var message="Metin2NewLegends - Web Security. All rights reserved.";

	/////////////////////////////////// 
	function clickIE4(){ 
	if (event.button==2){ 
	alert(message); 
	return false; 
	} 
	} 

	function clickNS4(e){ 
	if (document.layers||document.getElementById&&!document.all){ 
	if (e.which==2||e.which==3){ 
	alert(message); 
	return false; 
	} 
	} 
	} 

	if (document.layers){ 
	document.captureEvents(Event.MOUSEDOWN); 
	document.onmousedown=clickNS4; 
	} 
	else if (document.all&&!document.getElementById){ 
	document.onmousedown=clickIE4; 
	} 

	document.oncontextmenu=new Function("alert(message);return false") 

	// -->  
</script>

	
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="robots" content="noindex" />
		<meta name="googlebot" content="noindex" />
		<meta name="googlebot-news" content="noindex" />
		<meta name="description" content="Metin2NewLegends este un server privat romanesc. MOD JOC: PVM Medium."/>
		<meta name="keywords" content="Metin2NL,Metin2NewLegends,Metin2NewLegend,NL,Metin2,NLMetin2,Kyoura,P Server,Metin2,metin,Topliste,Toplist,Pserver,private Server,pserver,server,privat,privatserver,privat server,root,hamachi,p-server,community,toplist,liste"/>
		<link rel="stylesheet" href="style.css">
		<title> - home</title>
			
	</head>
	
	

	<body>

		<div id="navigation">
			<ul>
				<li class="first"><a href="index.php">ACASĂ<div class="nav-trenn"></div></a></li>
				<li class="middle"><a href="?page=register">ÎNREGISTRARE<div class="nav-trenn"></div></a></li>
				<li class="middle"><a href="?page=download">DESCARCĂ<div class="nav-trenn"></div></a></li>
				<li class="middle"><a href="?page=players">CLASAMENT<div class="nav-trenn"></div></a></li>
				<li class="middle"><a href="/site/ishop">MAGAZIN ONLINE<div class="nav-trenn"></div></a></li>
				<li class="last"><a href="LINK PREZENTARE">PREZENTARE SERVER</a></li>
			</ul>
		</div>
		<div id="player-online">
			<div id="po-placeholder"></div>
			<p class="anzahl">
				<span class="badge"><b>2</b></span>			</p>
			<span style="font-size: 10px;">Jucători online</span>
		</div>


		
		<div id="header">
		
		</div>
		
		<div id="content">
			<div class="con-top"></div>
			<div class="con-mid">
				<div class="left">				
					
</table><br/> 
				</div>
				<div class="right">
					<div class="status">
						<div class="status-head">
							<h3>Autentificare</h3>
							<a class="reload" href="#"></a>
						</div>
						<div class="status-table">
							
<center>
		   
			   
						<form name="loginForm" id="loginForm" style="margin:0;padding:0;" action="index.php?page=login" method="post">
							<div></br>
								<input AUTOCOMPLETE="off" type="text" class="form-control" id="username" name="user" maxlength="16" value="" placeholder="Utilizator"/>
							</div>
							<div>
								<input AUTOCOMPLETE="off" type="password" class="form-control" id="password" name="pw" maxlength="16" value="" placeholder="Parol&#259;"/>
							</div>

							</br>
							<input id="submitBtn" class="button" type="submit" name="login" value="Logare"/><a href="index.php?page=passwordlost" class="btn-btn-warning" style="float:left;margin:0;padding:0;-webkit-margin-start: 12px;">Ai uitat parola?</a>
							
						</form>		
							</center>
  						</div>
					</div>
					<div class="sr-placeholder"></div>
					<div class="status-ranking">
						<div class="status-ranking-head">
							<h3>Clasament Jucători</h3>
							<a class="reload" href="#"></a>
						</div>
						<div class="status-ranking-table" style="height:21.2%">
							        <div class="panel panel-default">
         	<div class="panel-body">

<div class="tab-content">
  <div class="tab-pane active">
			<table class="table-striped" style="line-height:15px; text-align:center;">
            <thead>
              <tr>
                <th>Nr.</th>
                <th>Rasa</th>
                <th>Nume</th>
                <th>Nivel</th>
              </tr>
            </thead>
            <tbody>
<tr>
                <td style="color:#f6d663;"><span class="badge">1</span></td>
				<td><a href="index.php?page=player&char=kYOURA"><img src="images/chars/misc/5.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=players">kYOURA</a></td>
                <td style="color:#f6d663;">120</td>
              </tr><tr>
                <td style="color:#f6d663;"><span class="badge">2</span></td>
				<td><a href="index.php?page=player&char=da"><img src="images/chars/misc/2.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=players">da</a></td>
                <td style="color:#f6d663;">120</td>
              </tr><tr>
                <td style="color:#f6d663;"><span class="badge">3</span></td>
				<td><a href="index.php?page=player&char=ItiDauCancer"><img src="images/chars/misc/5.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=players">ItiDauCancer</a></td>
                <td style="color:#f6d663;">120</td>
              </tr><tr>
                <td style="color:#f6d663;"><span class="badge">4</span></td>
				<td><a href="index.php?page=player&char=Ceyandme"><img src="images/chars/misc/5.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=players">Ceyandme</a></td>
                <td style="color:#f6d663;">120</td>
              </tr><tr>
                <td style="color:#f6d663;"><span class="badge">5</span></td>
				<td><a href="index.php?page=player&char=Tester"><img src="images/chars/misc/0.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=players">Tester</a></td>
                <td style="color:#f6d663;">99</td>
              </tr>	

            </tbody>
          </table>
	<center><a href="?page=players" class="button">Clasament complet &#187;</a></center>
  </div>
</div>


</div>
        </div>						</div>
					</div>
					<div class="sr-placeholder"></div>
					<div class="status-ranking">
						<div class="status-ranking-head">
							<h3>Clasament Bresle</h3>
							<a class="reload" href="#"></a>
						</div>
						<div class="status-ranking-table" style="height:21.2%">
							         <div class="panel panel-default">
         	<div class="panel-body">

<div class="tab-content">
  <div class="tab-pane active">
			<table class="table-striped" style="line-height:15px; text-align:center;">
            <thead>
              <tr>
                <th>Nr.</th>
				<th>Sigla</th>
                <th>Nume</th>
                <th>Nivel</th>
              </tr>
            </thead>
            <tbody>
<tr>
                <td style="color:#f6d663;"><span class="badge">1</span></td>
				<td><a href="index.php?page=player&char=STAFF"><img src="images/chars/misc/sigla.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=guilds" class="first">STAFF</a></td>
                <td style="color:#f6d663;">20</td>
              </tr><tr>
                <td style="color:#f6d663;"><span class="badge">2</span></td>
				<td><a href="index.php?page=player&char=WildStory"><img src="images/chars/misc/sigla.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=guilds" class="first">WildStory</a></td>
                <td style="color:#f6d663;">1</td>
              </tr><tr>
                <td style="color:#f6d663;"><span class="badge">3</span></td>
				<td><a href="index.php?page=player&char=STAFF"><img src="images/chars/misc/sigla.png" height="30" width="30"></a></td>
                <td><a href="index.php?page=guilds" class="first">STAFF</a></td>
                <td style="color:#f6d663;">1</td>
              </tr>	
            </tbody>
          </table>
		<center><a href="?page=guilds" class="button">Clasament complet &#187;</a></center>
  </div>
  
  </div>


</div>
        </div>						</div>
					</div>
					<div class="sr-placeholder"></div>
					<div class="staff-list">
						<div class="staff-list-head">
							<h3>Echipa Jocului</h3>
							<a class="reload" href="#"></a>
						</div>
						<div class="staff-list-table" style="height:21.2% >
							         	<div class="panel-body">
			<table class="table table-striped" style="line-height:15px; text-align:center;">

			
<div class="tab-content">
  <div class="tab-pane active">
			<table class="table-striped" style="line-height:15px; text-align:center;">
            <thead>
              <tr>
                <th>Nume</th>
                <th>Nivel</th>
				<th>Regat</th>
				<th>Status</th>
              </tr>
            </thead>
            <tbody>
			
            <tbody>

<tr><td><a href="index.php?page=players">[GM]Throne</a></td><td style="color:#f6d663;">120</td><td><img src="images/regat/3.jpg"></td>	</td><td><img src="./images/offline.png"></td><tr><td><a href="index.php?page=players">[OwN]Sm0Ke</a></td><td style="color:#f6d663;">120</td><td><img src="images/regat/3.jpg"></td>	</td><td><img src="./images/offline.png"></td><tr><td><a href="index.php?page=players">[SA]SkyLord</a></td><td style="color:#f6d663;">120</td><td><img src="images/regat/3.jpg"></td>	</td><td><img src="./images/offline.png"></td><tr><td><a href="index.php?page=players">[TEH]Kyoura</a></td><td style="color:#f6d663;">120</td><td><img src="images/regat/1.jpg"></td>	</td><td><img src="./images/offline.png"></td><tr><td><a href="index.php?page=players">Tester</a></td><td style="color:#f6d663;">99</td><td><img src="images/regat/2.jpg"></td>	</td><td><img src="./images/offline.png"></td><tr><td><a href="index.php?page=players">Costy</a></td><td style="color:#f6d663;">61</td><td><img src="images/regat/3.jpg"></td>	</td><td><img src="./images/offline.png"></td><tr><td><a href="index.php?page=players">Ceyandme</a></td><td style="color:#f6d663;">120</td><td><img src="images/regat/1.jpg"></td>	</td><td><img src="./images/offline.png"></td></tr>            </tbody>
          </table>
</div>						</div>
					</div>
					<div class="sr-placeholder"></div>
				</div>				
			</div>
			<div class="con-bot">
			</div>
		</div>

		<div id="footer">
			<p class="copyright" >
				<br>
				Powered by <a href="http://metin2nl.cf/">Metin2NewLegends</a> V 1.18.<br>
				Copyright 2017 &copy; <a href="#"></a>. All Rights reserved.<br>
				Designed by <a href="#">SFX</a>. Coded by <a href="http://www.twix-work.com">TWIX-Work</a>.
			</p>
		</div>
		
<

 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">

 


	</body>
</html>